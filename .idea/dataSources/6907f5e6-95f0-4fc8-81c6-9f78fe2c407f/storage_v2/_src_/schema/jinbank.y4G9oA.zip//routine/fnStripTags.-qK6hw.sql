CREATE FUNCTION fnStripTags(Dirty VARCHAR(4000))
  RETURNS VARCHAR(4000)
  BEGIN  
  DECLARE iStart, iEnd, iLength INT;   
    WHILE LOCATE( '<', Dirty ) > 0 AND LOCATE( '>', Dirty, LOCATE( '<', Dirty )) > 0 DO   
      BEGIN  
        SET iStart = LOCATE( '<', Dirty ), iEnd = LOCATE( '>', Dirty, LOCATE('<', Dirty ));   
        SET iLength = ( iEnd - iStart) + 1;   
        IF iLength > 0 THEN  
          BEGIN  
            SET Dirty = INSERT( Dirty, iStart, iLength, '');   
          END;   
        END IF;   
      END;   
    END WHILE;   
    RETURN Dirty;   
END;

