CREATE FUNCTION nextval(seq_name VARCHAR(50), skip_num INT)
  RETURNS INT
  COMMENT 'true'
  BEGIN  
DECLARE order_num INT;
SELECT order_id INTO order_num FROM biz_ordernumber WHERE order_type = seq_name FOR UPDATE;
IF ( order_num+skip_num >= 999999 ) THEN
    SET order_num = 100000;
END IF;
         UPDATE biz_ordernumber  
                   SET order_id = order_num + skip_num  
                   WHERE order_type = seq_name;  
         RETURN currval(seq_name);  
END;

