CREATE FUNCTION currval(seq_name VARCHAR(50))
  RETURNS INT
  COMMENT 'true'
  BEGIN  
         DECLARE VALUE INTEGER;  
         SET VALUE = 0;  
         SELECT order_id INTO VALUE  
                   FROM biz_ordernumber  
                   WHERE order_type = seq_name;
         RETURN VALUE;  
END;

